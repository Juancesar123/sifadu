<!-- No Ktp Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_KTP', 'No Ktp:'); ?>

    <?php echo Form::text('no_KTP', null, ['class' => 'form-control']); ?>

</div>

<!-- Nama Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Alamat Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('alamat', 'Alamat:'); ?>

    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Kondisi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('kondisi', 'Kondisi:'); ?>

    <?php echo Form::text('kondisi', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Status Penanganan Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status_penanganan', 'Status Penanganan:'); ?>

    <?php echo Form::text('status_penanganan', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- biaya renovasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('biaya_renovasi', 'Biaya Renovasi :'); ?>

    <?php echo Form::text('biaya_renovasi', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Gambar awal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('gambar_awal', 'Gambar Awal :'); ?>

    <?php echo Form::file('gambar_awal', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Gambar pasca renov Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('gambar_sesudah', 'Gambar Pasca Renov :'); ?>

    <?php echo Form::file('gambar_sesudah', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('rutilahus.index'); ?>" class="btn btn-default">Cancel</a>
</div>
