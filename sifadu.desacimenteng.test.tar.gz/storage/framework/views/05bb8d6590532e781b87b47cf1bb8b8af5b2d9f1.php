<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $datasuratmasuk->id; ?></p>
</div>

<!-- Kode Surat Field -->
<div class="form-group">
    <?php echo Form::label('kode_surat', 'Kode Surat:'); ?>

    <p><?php echo $datasuratmasuk->kode_surat; ?></p>
</div>

<!-- Nomor Surat Field -->
<div class="form-group">
    <?php echo Form::label('nomor_surat', 'Nomor Surat:'); ?>

    <p><?php echo $datasuratmasuk->nomor_surat; ?></p>
</div>

<!-- Penerima Field -->
<div class="form-group">
    <?php echo Form::label('penerima', 'Penerima:'); ?>

    <p><?php echo $datasuratmasuk->penerima; ?></p>
</div>

<!-- Tanggal Keluar Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_keluar', 'Tanggal Keluar:'); ?>

    <p><?php echo $datasuratmasuk->tanggal_keluar; ?></p>
</div>

<!-- Perihal Field -->
<div class="form-group">
    <?php echo Form::label('perihal', 'Perihal:'); ?>

    <p><?php echo $datasuratmasuk->perihal; ?></p>
</div>

<!-- Tanda Tangan Field -->
<div class="form-group">
    <?php echo Form::label('tanda_tangan', 'Tanda Tangan:'); ?>

    <p><?php echo $datasuratmasuk->tanda_tangan; ?></p>
</div>

<!-- Atas Nama Field -->
<div class="form-group">
    <?php echo Form::label('atas_nama', 'Atas Nama:'); ?>

    <p><?php echo $datasuratmasuk->atas_nama; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $datasuratmasuk->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $datasuratmasuk->updated_at; ?></p>
</div>

