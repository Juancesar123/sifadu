<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $keputusanbpd->id; ?></p>
</div>

<!-- No Keputusan Field -->
<div class="form-group">
    <?php echo Form::label('no_keputusan', 'No Keputusan:'); ?>

    <p><?php echo $keputusanbpd->no_keputusan; ?></p>
</div>

<!-- Tentang Field -->
<div class="form-group">
    <?php echo Form::label('tentang', 'Tentang:'); ?>

    <p><?php echo $keputusanbpd->tentang; ?></p>
</div>

<!-- Tanggal Keputusan Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_keputusan', 'Tanggal Keputusan:'); ?>

    <p><?php echo $keputusanbpd->tanggal_keputusan; ?></p>
</div>

<!-- Uraian Singkat Field -->
<div class="form-group">
    <?php echo Form::label('uraian_singkat', 'Uraian Singkat:'); ?>

    <p><?php echo $keputusanbpd->uraian_singkat; ?></p>
</div>

<!-- Keterangan Field -->
<div class="form-group">
    <?php echo Form::label('keterangan', 'Keterangan:'); ?>

    <p><?php echo $keputusanbpd->keterangan; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $keputusanbpd->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $keputusanbpd->updated_at; ?></p>
</div>

