<!-- No KKl Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_kk', 'No KK :'); ?>

    <?php echo Form::number('no_kk', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- nama kepala kk Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama_kepala_kk', 'Nama Kepala KK :'); ?>

    <?php echo Form::text('nama_kepala_kk', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- Nama penderita Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama_penderita', 'Nama Penderita :'); ?>

    <?php echo Form::text('nama_penderita', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- usia field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('usia', 'Usia :'); ?>

    <?php echo Form::number('usia', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- diagnosa field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('diagnosa', 'Diagnosa :'); ?>

    <?php echo Form::text('diagnosa', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- rujukan field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rujukan', 'Rujukan :'); ?>

    <?php echo Form::text('rujukan', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- jaminan kesehatan field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('jaminan_kesehatan', 'Jaminan Kesehatan :'); ?>

    <?php echo Form::text('jaminan_kesehatan', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('penyakitmenular.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>
<?php $__env->stopSection(); ?>
