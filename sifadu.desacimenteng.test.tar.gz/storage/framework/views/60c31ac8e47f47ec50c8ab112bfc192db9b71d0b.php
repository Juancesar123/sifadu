<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Form Pengajuan KK
        </h1>
    </section>
    <div class="content">
        <div class="box box-primary">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <center>
                            <h3>Daftar List Nama Kartu Keluarga</h3>
                        </center>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>NIK/KTP</th>
                                        <th>Nama</th>
                                        <th>No Surat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data->detailkk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($item->nik); ?></td>
                                            <td><?php echo e($item->nama_lengkap); ?></td>
                                            <td><?php echo e($item->nomor_surat); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td class="text-center" colspan="3"><a href="<?php echo e(route('detailkk.edit', $data->nomor_surat)); ?>" style="text-decoration: none;"><i class="fa fa-plus"></i>Tambah Nama di KK</a></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e(route('detailkk.edit', $data->nomor_surat)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-pencil-square-o"></i>
                        Edit Nama Kepala Keluarga <strong><?php echo e(isset($data->datapenduduk) && $data->datapenduduk != null ? $data->datapenduduk->nama_lengkap : '-'); ?></strong>
                        </a>
                        <a href="<?php echo route('formpengajuankk.index'); ?>" class="btn btn-default"><?php echo e(__('Back')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>