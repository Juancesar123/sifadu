<!-- nama pemilik Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pemilik', 'Nama Pemilik :'); ?>

    <?php echo Form::text('pemilik', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- lokasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('lokasi', 'Lokasi :'); ?>

    <?php echo Form::text('lokasi', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- modal usaha Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('modal_usaha', 'Modal Usaha :'); ?>

    <?php echo Form::number('modal_usaha', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Nama Produk Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('produk_dagang', 'Produk Dagang :'); ?>

    <?php echo Form::text('produk_dagang', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Omset Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('omset', 'Omset perbulan :'); ?>

    <?php echo Form::number('omset', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('datawarung.index'); ?>" class="btn btn-default">Cancel</a>
</div>
