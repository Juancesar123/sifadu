<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $suratketeranganusaha->id; ?></p>
</div>

<!-- Nik Field -->
<div class="form-group">
    <?php echo Form::label('nik', 'Nik:'); ?>

    <p><?php echo $suratketeranganusaha->nik; ?></p>
</div>

<!-- Nomor Surat Field -->
<div class="form-group">
    <?php echo Form::label('nomor_surat', 'Nomor Surat:'); ?>

    <p><?php echo $suratketeranganusaha->nomor_surat; ?></p>
</div>

<!-- Footer Cetak Data Field -->
<div class="form-group">
    <?php echo Form::label('footer_cetak_data', 'Footer Cetak Data:'); ?>

    <p><?php echo $suratketeranganusaha->footer_cetak_data; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $suratketeranganusaha->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $suratketeranganusaha->updated_at; ?></p>
</div>

