<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $agama->id; ?></p>
</div>

<!-- Agama Field -->
<div class="form-group">
    <?php echo Form::label('agama', 'Agama:'); ?>

    <p><?php echo $agama->agama; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $agama->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $agama->updated_at; ?></p>
</div>

