<li class="treeview">
    <a href="#">
        <i class="fa fa-database"></i>
        <span>Master Data</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('parameterjeniskelamins*') ? 'active' : ''); ?>">
            <a href="<?php echo route('parameterjeniskelamins.index'); ?>"><i class="fa fa-circle-o"></i>Jenis Kelamin</a>
        </li>
        
        <li class="<?php echo e(Request::is('parameterstatuskawins*') ? 'active' : ''); ?>">
            <a href="<?php echo route('parameterstatuskawins.index'); ?>"><i class="fa fa-circle-o"></i>Status Kawin</a>
        </li><li class="<?php echo e(Request::is('jenispekerjaans*') ? 'active' : ''); ?>">
            <a href="<?php echo route('jenispekerjaans.index'); ?>"><i class="fa fa-circle-o"></i>Jenis Pekerjaan</a>
        </li>
        
        <li class="<?php echo e(Request::is('pendidikans*') ? 'active' : ''); ?>">
            <a href="<?php echo route('pendidikans.index'); ?>"><i class="fa fa-circle-o"></i>Pendidikan</a>
        </li>
        
        <li class="<?php echo e(Request::is('dusuns*') ? 'active' : ''); ?>">
            <a href="<?php echo route('dusuns.index'); ?>"><i class="fa fa-circle-o"></i>Dusun</a>
        </li>
        
        <li class="<?php echo e(Request::is('agamas*') ? 'active' : ''); ?>">
            <a href="<?php echo route('agamas.index'); ?>"><i class="fa fa-circle-o"></i>Agama</a>
        </li>                
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-users"></i>
        <span>Data Kependudukan</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('datapenduduks*') ? 'active' : ''); ?>">
            <a href="<?php echo route('datapenduduks.index'); ?>"><i class="fa fa-circle-o"></i>Data Penduduk</a>
        </li>    
        <li class="<?php echo e(Request::is('pendudukmeninggals*') ? 'active' : ''); ?>">
            <a href="<?php echo route('pendudukmeninggals.index'); ?>"><i class="fa fa-circle-o"></i>Penduduk Meninggal</a>
        </li>
        <li class="<?php echo e(Request::is('pendudukpindahs*') ? 'active' : ''); ?>">
            <a href="<?php echo route('pendudukpindahs.index'); ?>"><i class="fa fa-circle-o"></i>Penduduk Pindah</a>
        </li>
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-building"></i>
        <span>Data Pembangunan</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('rencanapembangunans*') ? 'active' : ''); ?>">
            <a href="<?php echo route('rencanapembangunans.index'); ?>"><i class="fa fa-circle-o"></i>Rencana Pembangunan</a>
        </li>
        <li class="<?php echo e(Request::is('kegiatanpembangunans*') ? 'active' : ''); ?>">
            <a href="<?php echo route('kegiatanpembangunans.index'); ?>"><i class="fa fa-circle-o"></i>Kegiatan Pembangunan</a>
        </li>
        
        <li class="<?php echo e(Request::is('inventarisproyeks*') ? 'active' : ''); ?>">
            <a href="<?php echo route('inventarisproyeks.index'); ?>"><i class="fa fa-circle-o"></i>Inventaris Proyek</a>
        </li>
        
        <li class="<?php echo e(Request::is('kaderpembangunans*') ? 'active' : ''); ?>">
            <a href="<?php echo route('kaderpembangunans.index'); ?>"><i class="fa fa-circle-o"></i>Kader Pembangunan</a>
        </li>            
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-envelope"></i>
        <span>Surat</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">        
        <li class="<?php echo e(Request::is('suratpengantarktps*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratpengantarktps.index'); ?>"><i class="fa fa-circle-o"></i> Pengantar KTP</a>
        </li>
        <li class="<?php echo e(Request::is('suratpengantarkks*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratpengantarkks.index'); ?>"><i class="fa fa-circle-o"></i> Pengantar KK</a>
        </li>
        <li class="<?php echo e(Request::is('suratketerangantidakmampus*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketerangantidakmampus.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan Tidak Mampu</a>
        </li>   
        <li class="<?php echo e(Request::is('suratketerangandomisilis*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketerangandomisilis.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan Domisili</a>
        </li> 
        <li class="<?php echo e(Request::is('suratketeranganskcks*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketeranganskcks.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan SKCK</a>
        </li>
        <li class="<?php echo e(Request::is('suratketeranganusahas*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketeranganusahas.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan Usaha</a>
        </li>
        <li class="<?php echo e(Request::is('suratketeranganpenguasaantanahs*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketeranganpenguasaantanahs.index'); ?>"><i class="fa fa-circle-o"></i>Keterangan Penguasaan <p style="margin-left:17px">Tanah</p></a>
        </li>
        <li class="<?php echo e(Request::is('suratketeranganlainnyas*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketeranganlainnyas.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan Lainnya</a>
        </li>
        <li class="<?php echo e(Request::is('suratketerangandesas*') ? 'active' : ''); ?>">
            <a href="<?php echo route('suratketerangandesas.index'); ?>"><i class="fa fa-circle-o"></i> Keterangan Desa</a>
        </li>

    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-users"></i>
        <span>Admin BPD</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('keputusanbpds*') ? 'active' : ''); ?>">
            <a href="<?php echo route('keputusanbpds.index'); ?>"><i class="fa fa-circle-o"></i><span>Keputusan BPD</span></a>
        </li>
            
        <li class="<?php echo e(Request::is('anggotabpds*') ? 'active' : ''); ?>">
            <a href="<?php echo route('anggotabpds.index'); ?>"><i class="fa fa-circle-o"></i><span>Anggota BPD</span></a>
        </li>   

        <li class="<?php echo e(Request::is('kegiatanbpds*') ? 'active' : ''); ?>">
            <a href="<?php echo route('kegiatanbpds.index'); ?>"><i class="fa fa-circle-o"></i><span>Kegiatan BPD</span></a>
        </li>

        <li class="<?php echo e(Request::is('agendabpds*') ? 'active' : ''); ?>">
            <a href="<?php echo route('agendabpds.index'); ?>"><i class="fa fa-circle-o"></i><span>Agenda BPD</span></a>
        </li>

        <li class="<?php echo e(Request::is('dataekspedisis*') ? 'active' : ''); ?>">
            <a href="<?php echo route('dataekspedisis.index'); ?>"><i class="fa fa-circle-o"></i><span>Data Ekspedisi</span></a>
        </li>              
    </ul>
</li>

<li class="treeview">
    <a href="#">
        <i class="fa fa-exchange"></i>
        <span>Arsip Surat</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('datasuratmasuks*') ? 'active' : ''); ?>">
            <a href="<?php echo route('datasuratmasuks.index'); ?>"><i class="fa fa-circle-o"></i><span>Data Surat Masuk</span></a>
        </li>
        <li class="<?php echo e(Request::is('datasuratkeluars*') ? 'active' : ''); ?>">
            <a href="<?php echo route('datasuratkeluars.index'); ?>"><i class="fa fa-circle-o"></i><span>Data Surat Keluar</span></a>
        </li>
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-percent"></i>
        <span>PBB</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">        
        <li class="<?php echo e(Request::is('pajaktanahs*') ? 'active' : ''); ?>">
            <a href="<?php echo route('pajaktanahs.index'); ?>"><i class="fa fa-circle-o"></i>Pajak Tanah</a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="#">
        <i class="fa fa-pie-chart"></i>
        <span>Statistik</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li><a href="statistikpendidikan"><i class="fa fa-circle-o"></i> Statistik Pendidikan</a></li>
        <li><a href="statistikpekerjaan"><i class="fa fa-circle-o"></i> Statistik Pekerjaan</a></li>
        <li><a href="statistikstatusperkawinan"><i class="fa fa-circle-o"></i> Statistik Status Perkawinan</a></li>
        <li><a href="statistikagama"><i class="fa fa-circle-o"></i> Statistik Agama</a></li>
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-building"></i>
        <span>Prasarana</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">
        <li><a href=""><i class="fa fa-circle-o"></i> Kesehatan</a></li>
        <li><a href=""><i class="fa fa-circle-o"></i> Pendidikan</a></li>
        <li><a href=""><i class="fa fa-circle-o"></i> Tempat Ibadah</a></li>
        <li><a href=""><i class="fa fa-circle-o"></i> Sarana Umum</a></li>
    </ul>
</li>
<li>
    <a href="">
      <i class="fa fa-users"></i> <span>Kemiskinan&pengangguran</span>
    </a>
  </li>

<?php $__env->startSection('css'); ?>
<style>
    .disabled {
    pointer-events:none; 
    opacity:0.6;        
}
</style>

<?php $__env->stopSection(); ?>
    





