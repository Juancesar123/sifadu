<!-- Nik Field -->
<div class="form-group col-sm-6">
        <?php echo Form::label('nik_atau_nama', 'Nik:'); ?>

        <select class="form-control js-example-basic-single" name="nik">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key->id); ?>"><?php echo e($key->nik); ?> - <?php echo e($key->nama_lengkap); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    
<!-- Nomor Surat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nomor_surat', 'Nomor Surat:'); ?>

    <?php echo Form::text('nomor_surat', null, ['class' => 'form-control']); ?>

</div>

<!-- Footer Cetak Data Field -->
<!-- Footer Cetak Data Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('footer_cetak_data', 'Footer Cetak Data:'); ?>

    <?php echo Form::textarea('footer_cetak_data', null, ['class' => 'form-control']); ?>

</div>
    
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('suratketeranganskcks.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>
<?php $__env->stopSection(); ?>