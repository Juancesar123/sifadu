<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $madrasah->id; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('daftar_sarana', 'Daftar Sarana :'); ?>

    <p><?php echo $madrasah->daftar_sarana; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('penanggungjawab', 'Penanggungjawab :'); ?>

    <p><?php echo $madrasah->penanggungjawab; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('lokasi', 'Lokasi :'); ?>

    <p><?php echo $madrasah->lokasi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('kondisi', 'Kondisi :'); ?>

    <p><?php echo $madrasah->kondisi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('sdm', 'Sumber Daya Manusia :'); ?>

    <p><?php echo $madrasah->sumber_daya_manusia; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $madrasah->created_at; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $madrasah->updated_at; ?></p>
</div>
