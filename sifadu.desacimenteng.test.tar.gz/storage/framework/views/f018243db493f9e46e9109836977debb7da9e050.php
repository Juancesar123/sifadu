<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $perpustakaan->id; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('daftar_sarana', 'Daftar Sarana :'); ?>

    <p><?php echo $perpustakaan->daftar_sarana; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('penanggungjawab', 'Penanggungjawab :'); ?>

    <p><?php echo $perpustakaan->penanggungjawab; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('lokasi', 'Lokasi :'); ?>

    <p><?php echo $perpustakaan->lokasi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('kondisi', 'Kondisi :'); ?>

    <p><?php echo $perpustakaan->kondisi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('sdm', 'Sumber Daya Manusia :'); ?>

    <p><?php echo $perpustakaan->sumber_daya_manusia; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $perpustakaan->created_at; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $perpustakaan->updated_at; ?></p>
</div>
