<!-- daftar sarana Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('daftar_sarana', 'Daftar Sarana :'); ?>

    <?php echo Form::text('daftar_sarana', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- penanggungjawab Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('penanggungjawab', 'Penanggungjawab :'); ?>

    <?php echo Form::text('penanggungjawab', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- lokasi Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('lokasi', 'Lokasi :'); ?>

    <?php echo Form::text('lokasi', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- kondisi field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('kondisi', 'Kondisi :'); ?>

    <?php echo Form::text('kondisi', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- sdm field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('sdm', 'Sumber Daya Manusia :'); ?>

    <?php echo Form::text('sumber_daya_manusia', null, ['class' => 'form-control ' , 'required']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('rumahsakit.index'); ?>" class="btn btn-default">Cancel</a>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>
<?php $__env->stopSection(); ?>
