<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $perkebunan->id; ?></p>
</div>

<!-- Status Lahan Field -->
<div class="form-group">
    <?php echo Form::label('status_lahan', 'Status Lahan:'); ?>

    <p><?php echo $perkebunan->status_lahan; ?></p>
</div>

<!-- Jenis Budidaya Field -->
<div class="form-group">
    <?php echo Form::label('jenis_budidaya', 'Jenis Budidaya:'); ?>

    <p><?php echo $perkebunan->jenis_budidaya; ?></p>
</div>

<!-- Pengelola Field -->
<div class="form-group">
    <?php echo Form::label('pengelola', 'Pengelola:'); ?>

    <p><?php echo $perkebunan->pengelola; ?></p>
</div>

<!-- Penanggung Jawab Field -->
<div class="form-group">
    <?php echo Form::label('penanggung_jawab', 'Penanggung Jawab:'); ?>

    <p><?php echo $perkebunan->penanggung_jawab; ?></p>
</div>

<!-- Luas Area Field -->
<div class="form-group">
    <?php echo Form::label('luas_area', 'Luas Area:'); ?>

    <p><?php echo $perkebunan->luas_area; ?></p>
</div>

<!-- Masa Pengelolaan Field -->
<div class="form-group">
    <?php echo Form::label('masa_pengelolaan', 'Masa Pengelolaan:'); ?>

    <p><?php echo $perkebunan->masa_pengelolaan; ?></p>
</div>

<!-- hasil pertahun Field -->
<div class="form-group">
    <?php echo Form::label('hasil_pertahun', 'Hasil Pertahun:'); ?>

    <p><?php echo $perkebunan->hasil_pertahun; ?></p>
</div>

<?php echo $__env->make('leaflet.leaflet_1_3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Batas zona Field -->
<div class="form-group">
    <?php echo $__env->make('leaflet.show_custom', [
        'input_name' => 'perkebunan_koordinate', 
        'input_label' => 'Batas wilayah perkebunan', 
        'input_data' => (isset($perkebunan)) ? $perkebunan->perkebunan_koordinate[0] : Null,
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('leaflet.show_custom_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $perkebunan->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $perkebunan->updated_at; ?></p>
</div>
