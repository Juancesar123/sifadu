

<?php $__env->startSection('css'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Custom Data
        </h1>
    </section>
    <div class="content">
        <?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="box box-primary">

            <div class="box-body">
                <div class="row">
                    <?php echo Form::open(['route' => 'customDatas.store']); ?>


                        <?php echo $__env->make('custom_datas.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(function(){
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

    $('#Cat').on('change', function(){
        $('#SubCat').empty();
        val = $('#Cat').val()
        console.log("TCL: val", val)
        sub = $('#SubCat')
        
        $.ajax({
            url: "/marker/select/"+val,
            type: 'GET',
            data: { _token: CSRF_TOKEN},
            success: function (response) {
                sub.empty();
                response.map( e => {
                    if (e == null){
                        sub.prop('disabled', true);
                    } else {
                        sub.append(`<option value=${e}>${e}</option>`)
                    }
                })
            },
            error: function (response){
                sub.empty()
                sub.prop('disabled', true);
            }
        });
    })
})
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>