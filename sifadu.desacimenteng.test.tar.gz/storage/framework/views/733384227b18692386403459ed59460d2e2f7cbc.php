<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $daftarPemilihTetap->id; ?></p>
</div>

<!-- No Ktp Field -->
<div class="form-group">
    <?php echo Form::label('no_KTP', 'No Ktp:'); ?>

    <p><?php echo $daftarPemilihTetap->no_KTP; ?></p>
</div>

<!-- Nama Field -->
<div class="form-group">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <p><?php echo $daftarPemilihTetap->nama; ?></p>
</div>

<!-- Alamat Field -->
<div class="form-group">
    <?php echo Form::label('alamat', 'Alamat:'); ?>

    <p><?php echo $daftarPemilihTetap->alamat; ?></p>
</div>

<!-- Pekerjaan Field -->
<div class="form-group">
    <?php echo Form::label('pekerjaan', 'Pekerjaan:'); ?>

    <p><?php echo $daftarPemilihTetap->pekerjaan; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $daftarPemilihTetap->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $daftarPemilihTetap->updated_at; ?></p>
</div>

