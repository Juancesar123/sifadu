<!-- Penduduk Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('penduduk_id', 'Nama Lengkap:'); ?>

    <select class="form-control js-example-basic-single" id="penduduk_id" name="penduduk_id">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key->id); ?>"><?php echo e($key->nama_lengkap); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- NIK Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nik', 'NIK :'); ?>

    <?php echo Form::text('nik', null, ['class' => 'form-control', 'required']); ?>

</div>

<!-- NO KK Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('no_kk', 'No KK :'); ?>

    <?php echo Form::text('no_kk', null, ['class' => 'form-control', 'required']); ?>

</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('kemiskinan.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});


// var penduduk_id = getElementsById('penduduk_id');

jQuery(document).ready(function(){
            jQuery('#penduduk_id').change(function(e){
               e.preventDefault();
               jQuery.ajax({
                  url: "<?php echo e(url('/kemiskinan/getnik')); ?>",
                  method: 'get',
                  success: function(response){
                     console.log(response);
                  }});
               });
            });
</script>
<?php $__env->stopSection(); ?>
