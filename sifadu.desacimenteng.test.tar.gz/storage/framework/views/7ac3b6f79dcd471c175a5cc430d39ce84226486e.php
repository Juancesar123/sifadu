<!-- Nama Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

</div>

<!-- Jenis Kelamin Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('jenis_kelamin', 'Jenis Kelamin:'); ?>

    <?php echo Form::select('jenis_kelamin', ['1' => 'Laki-Laki', '0' => 'Perempuan'], null, ['class' => 'form-control']); ?>

</div>

<!-- Tempat Lahir Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tempat_lahir', 'Tempat Lahir:'); ?>

    <?php echo Form::text('tempat_lahir', null, ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Lahir Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_lahir', 'Tanggal Lahir:'); ?>

    <?php echo Form::date('tanggal_lahir', null, ['class' => 'form-control']); ?>

</div>

<!-- Agama Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('agama', 'Agama:'); ?>

    <?php echo Form::select('agama', ['1' => 'Islam', '2' => 'Kristen', '3' => 'Katolik', '4' => 'Hindu', '5' => 'Budha', '6' => 'Lainnya'], null, ['class' => 'form-control']); ?>

</div>

<!-- Pendidikan Terakhir Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pendidikan_terakhir', 'Pendidikan Terakhir:'); ?>

    <?php echo Form::text('pendidikan_terakhir', null, ['class' => 'form-control']); ?>

</div>

<!-- Nomor Keputusan Pengangkatan Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nomor_keputusan_pengangkatan', 'Nomor Keputusan Pengangkatan:'); ?>

    <?php echo Form::text('nomor_keputusan_pengangkatan', null, ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Keputusan Pengangkatan Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_keputusan_pengangkatan', 'Tanggal Keputusan Pengangkatan:'); ?>

    <?php echo Form::date('tanggal_keputusan_pengangkatan', null, ['class' => 'form-control']); ?>

</div>

<!-- Nomor Keputusan Pemberentian Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nomor_keputusan_pemberentian', 'Nomor Keputusan Pemberentian:'); ?>

    <?php echo Form::text('nomor_keputusan_pemberentian', null, ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Keputusan Pemberentian Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_keputusan_pemberentian', 'Tanggal Keputusan Pemberentian:'); ?>

    <?php echo Form::date('tanggal_keputusan_pemberentian', null, ['class' => 'form-control']); ?>

</div>

<!-- Keterangan Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('keterangan', 'Keterangan:'); ?>

    <?php echo Form::textarea('keterangan', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('anggotabpds.index'); ?>" class="btn btn-default">Cancel</a>
</div>
