<!-- Kode Surat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('kode_surat', 'Kode Surat:'); ?>

    <?php echo Form::text('kode_surat', null, ['class' => 'form-control']); ?>

</div>

<!-- Nomor Surat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nomor_surat', 'Nomor Surat:'); ?>

    <?php echo Form::text('nomor_surat', null, ['class' => 'form-control']); ?>

</div>

<!-- Penerima Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('penerima', 'Penerima:'); ?>

    <?php echo Form::text('penerima', null, ['class' => 'form-control']); ?>

</div>

<!-- Tanggal Keluar Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanggal_keluar', 'Tanggal Keluar:'); ?>

    <?php echo Form::date('tanggal_keluar', null, ['class' => 'form-control']); ?>

</div>

<!-- Perihal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('perihal', 'Perihal:'); ?>

    <?php echo Form::textarea('perihal', null, ['class' => 'form-control summernote']); ?>

</div>

<!-- Tanda Tangan Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tanda_tangan', 'Tanda Tangan:'); ?>

    <?php echo Form::text('tanda_tangan', null, ['class' => 'form-control']); ?>

</div>

<!-- Atas Nama Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('atas_nama', 'Atas Nama:'); ?>

    <?php echo Form::text('atas_nama', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('datasuratmasuks.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php $__env->startSection('scripts'); ?>
<script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });
</script>
<?php $__env->stopSection(); ?>
 