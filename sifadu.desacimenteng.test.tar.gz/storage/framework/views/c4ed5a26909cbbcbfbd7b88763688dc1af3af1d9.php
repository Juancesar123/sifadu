<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $pendudukpindah->id; ?></p>
</div>

<!-- Penduduk Id Field -->
<div class="form-group">
    <?php echo Form::label('penduduk_id', 'Penduduk Id:'); ?>

    <p><?php echo $pendudukpindah->penduduk_id; ?></p>
</div>

<!-- Tanggal Pindah Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_pindah', 'Tanggal Pindah:'); ?>

    <p><?php echo $pendudukpindah->tanggal_pindah; ?></p>
</div>

<!-- Keterangan Pindah Field -->
<div class="form-group">
    <?php echo Form::label('keterangan_pindah', 'Keterangan Pindah:'); ?>

    <p><?php echo $pendudukpindah->keterangan_pindah; ?></p>
</div>

<!-- Pindah Ke Field -->
<div class="form-group">
    <?php echo Form::label('pindah_ke', 'Pindah Ke:'); ?>

    <p><?php echo $pendudukpindah->pindah_ke; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $pendudukpindah->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $pendudukpindah->updated_at; ?></p>
</div>

