<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $sd->id; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('daftar_sarana', 'Daftar Sarana :'); ?>

    <p><?php echo $sd->daftar_sarana; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('penanggungjawab', 'Penanggungjawab :'); ?>

    <p><?php echo $sd->penanggungjawab; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('lokasi', 'Lokasi :'); ?>

    <p><?php echo $sd->lokasi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('kondisi', 'Kondisi :'); ?>

    <p><?php echo $sd->kondisi; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('sdm', 'Sumber Daya Manusia :'); ?>

    <p><?php echo $sd->sumber_daya_manusia; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $sd->created_at; ?></p>
</div>

<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $sd->updated_at; ?></p>
</div>
