<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $pendudukmeninggal->id !!}</p>
</div>

<!-- Penduduk Id Field -->
<div class="form-group">
    {!! Form::label('penduduk_id', 'Penduduk Id:') !!}
    <p>{!! $pendudukmeninggal->penduduk_id !!}</p>
</div>

<!-- Tanggal Meninggal Field -->
<div class="form-group">
    {!! Form::label('tanggal_meninggal', 'Tanggal Meninggal:') !!}
    <p>{!! $pendudukmeninggal->tanggal_meninggal !!}</p>
</div>

<!-- Keterangan Meninggal Field -->
<div class="form-group">
    {!! Form::label('keterangan_meninggal', 'Keterangan Meninggal:') !!}
    <p>{!! $pendudukmeninggal->keterangan_meninggal !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Dibuat pada:') !!}
    <p>{!! $pendudukmeninggal->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Diperbarui pada:') !!}
    <p>{!! $pendudukmeninggal->updated_at !!}</p>
</div>

