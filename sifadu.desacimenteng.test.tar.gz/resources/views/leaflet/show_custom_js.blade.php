<script src="{{asset('/js/show_custom_geom.js')}}"></script>

