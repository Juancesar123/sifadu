<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $rutilahu->id !!}</p>
</div>

<!-- No Ktp Field -->
<div class="form-group">
    {!! Form::label('no_KTP', 'No Ktp:') !!}
    <p>{!! $rutilahu->no_KTP !!}</p>
</div>

<!-- Nama Field -->
<div class="form-group">
    {!! Form::label('nama', 'Nama:') !!}
    <p>{!! $rutilahu->nama !!}</p>
</div>

<!-- Alamat Field -->
<div class="form-group">
    {!! Form::label('alamat', 'Alamat:') !!}
    <p>{!! $rutilahu->alamat !!}</p>
</div>

<!-- Kondisi Field -->
<div class="form-group">
    {!! Form::label('kondisi', 'Kondisi:') !!}
    <p>{!! $rutilahu->kondisi !!}</p>
</div>

<!-- Status Penanganan Field -->
<div class="form-group">
    {!! Form::label('status_penanganan', 'Status Penanganan:') !!}
    <p>{!! $rutilahu->status_penanganan !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Dibuat pada:') !!}
    <p>{!! $rutilahu->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Diperbarui pada:') !!}
    <p>{!! $rutilahu->updated_at !!}</p>
</div>

