<div class="modal fade" id="selectPointModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Buat Ruas Baru</h5>
      </div>

      <div class="modal-body select-point">
        <div id="selectPointCanvas"></div>
      </div>

      <div class="modal-footer">
        {{-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> --}}
        <button id="okPointModal" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>